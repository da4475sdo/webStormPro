/**
 * Created by Administrator on 2015/9/14.
 */
window.onload=function(){
    buildPalindrome();
};


/** 生成0到输入数字的回文*/
function buildPalindrome(){
    var number=parseInt(prompt("请输入一个数字：",""),10);
    if(Object.prototype.toString.call(number)==='[object Number]'){
        //回文字符串
        var palindrome=number;
        for(var i= parseInt(number,10)-1;i>0;i--){
            //连接首部
            palindrome=i+""+palindrome;
            //连接尾部
            palindrome+=""+i;
        }
        //在页面上输出回文
        document.write(palindrome+"");
    }else{
        alert("您输入的不是数字，请重新输入");
        location.reload();
    }
}