/**
 * Created by Administrator on 2015/9/24.
 */
        (function (){
            setTimeout('Asynchronous1()',2000);
            setTimeout('Asynchronous2()',1000);
            Synchronous();
        })();

        function Asynchronous1(){
            var one=document.getElementById("1");
            console.log("异步：");
            one.innerHTML="我准备好了1 "+new Date().getTime();
        }

        function Asynchronous2(){
            var one=document.getElementById("3");
            console.log("异步：");
            one.innerHTML="我准备好了2 "+new Date().getTime();
        }

        function Synchronous(){
            var startTime=new Date().getTime();
            while(new Date().getTime()-startTime<=3000);
            document.getElementById("2").innerHTML="充能完毕，准备就绪"+new Date().getTime();
            console.log("充能完毕，准备就绪");
            startTime=new Date().getTime();
            while(new Date().getTime()-startTime<=3000);
        }