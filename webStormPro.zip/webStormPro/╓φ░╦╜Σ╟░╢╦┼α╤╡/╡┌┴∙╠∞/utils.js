/**
 * Created by Administrator on 2015/9/15.
 */
var utils = {
    // 生成唯一ID
    uuid: function(){
        var s = [];
        var hexDigits = "0123456789abcdef";
        for (var i = 0; i < 36; i++) {
            s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
        }
        s[8] = s[13] = s[18] = s[23] = "-";

        var uuid = s.join("");
        return uuid;
    },
    // 給 DOM 添加 className
    addClass: function( domObj, className ){
        var addClassName=className;
        var ownedClassName=domObj.className;
        //判断新增类名是否为空字符串
        if(addClassName.toString().trim().length!==0){
            //判断类型是否已经存在
            if(ownedClassName.indexOf(addClassName)===-1){
                domObj.className=ownedClassName+" "+addClassName;
            }
        }

    },
    // 去掉 DOM 上的某个 className
    removeClass: function( domObj, className ){
        var removeClassName=className;
        var ownedClassName=domObj.className;
        if(ownedClassName.toString().trim()
            &&ownedClassName.toString().trim()
            &&className.indexOf(removeClassName)!==-1){
            ownedClassName=ownedClassName.replace(" "+removeClassName+" "," ");
            domObj.className=ownedClassName;
        }
    },
    // 在当前的 domcument 上加载一个 script 脚本，加载完成后执行 cb
    loadScript: function( script, cb ){
        var xmlHttp = null;
        //要加载的js源文件地址
        var url = script.src;
        var scriptID=script.id;
        if(window.ActiveXObject)//IE
        {
            try {
                //IE6以及以后版本中可以使用
                xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (e) {
                //IE5.5以及以后版本可以使用
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
        }
        else if(window.XMLHttpRequest)//Firefox，Opera 8.0+，Safari，Chrome
        {
            xmlHttp = new XMLHttpRequest();
        }
        //采用同步加载
        xmlHttp.open("GET",url,false);
        xmlHttp.send(null);
        //数据发送完毕
        if ( xmlHttp.readyState == 4 )
        {
            //0为访问的本地，200到300代表访问服务器成功，304代表没做修改访问的是缓存
            if((xmlHttp.status >= 200 && xmlHttp.status <300) || xmlHttp.status == 0 || xmlHttp.status == 304)
            {
                var myHead = document.getElementsByTagName("head").item(0);
                var myScript = document.createElement( "script" );
                myScript.language = "javascript";
                myScript.type = "text/javascript";
                myScript.id = scriptID;
                try{
                    //IE8以及以下不支持这种方式，需要通过text属性来设置
                    myScript.appendChild(document.createTextNode(xmlHttp.responseText));
                }
                catch (ex){
                    myScript.text = xmlHttp.responseText;
                }
                myHead.appendChild( myScript );
                //如果cb是一个方法就执行
                typeof cb==='function'&&cb();
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    },
    // 返回一个不重复的数组
    uniqueArray: function( array ){
        var uniqueMap={};
        var uniqueArray=[];
        for(var i= 0,len=array.length;i<len;i++){
            var uniqueElement=array[i];
            if(!uniqueMap[uniqueElement]){
                uniqueMap[uniqueElement]=true;
                uniqueArray.push(uniqueElement);
            }
        }
        return uniqueArray;
    },
    // sup为父类的构造函数，sub为子类的构造函数。实现继承。用尽量多的方法完善该函数，例如原型链的方式，深克隆的方式等
    extend: function(sup,child) {
        var sub = child || {};
        for (var i in sup) {
            if (typeof sup[i] === 'object') {
                sub[i] = (sup[i].constructor === Array) ? [] : {};
                this.extend(sup[i], sub[i]);
            } else {
                sub[i] = sup[i];
            }
        }
        return sub;
    },
    // 类型判断
    isString: function(val){
        return typeof val === 'string';
    },
    isNumber: function( val ){
        return typeof val === 'number';
    },
    isObject: function( val ){
        return typeof val === 'object';
    },
    isArray: function( val ){
        return val instanceof Array;
    },
    isFunction: function( val ){
        return typeof val === 'function';
    }
};