/**
 * Created by Administrator on 2015/9/21.
 */
webPSwitch();

function webPSwitch(){
    var picList=document.getElementsByName("web-picture");
    var datetime=new Date().getTime();
    for(var i= 0,len=picList.length;i<len;i++){
        var pic=picList[i];
        if(pic.tagName==='IMG'){
            if(browserTesting()){
                pic.src=pic.attributes.webPSrc.value;
            }else{
                pic.src=pic.attributes.normalSrc.value;
            }
        }else{
            if(browserTesting()){
                pic.style.background='url("'+pic.attributes.bgWebP.value+'") no-repeat';
            }else{
                pic.style.background='url("'+pic.attributes.bgNormal.value+'") no-repeat';
            }
        }
    }
    alert("耗时："+(new Date().getTime()-datetime));
}

function browserTesting(){
    var isGoogle=navigator.userAgent.indexOf("Chrome")>0?true:false;
    return isGoogle;
}