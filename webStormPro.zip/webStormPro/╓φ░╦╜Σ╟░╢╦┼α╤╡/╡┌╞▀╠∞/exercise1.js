/**
 * Created by Administrator on 2015/9/16.
 */
var PPTArgument={
    srcArray:["image/content-pic.png","image/content-pic2.png","image/content-pic3.png"
        ,"image/content-pic4.png"],
    PPT:document.getElementById("PPT"),
    index:0
};

(function(){
    var handler=tabSwitch;
    var tabList=document.getElementById("works-head-list");

    utils.eventUtil.addEvent(tabList,"click",function(event){
        handler(event,tabList);
    });
    preLoad();
    plays();
})();


//预加载图片
function preLoad(){
    for(var i=0;i<4;i++){
        var image=new Image();
        image.src=PPTArgument.srcArray[i];
    }

    PPTArgument.PPT.style.background = 'url(' + PPTArgument.srcArray[0] + ') no-repeat right center';
}


//播放幻灯片
function plays() {
    var src = 'url(' + PPTArgument.srcArray[PPTArgument.index] + ') no-repeat right center';
    PPTArgument.PPT.style.background = src;
    PPTArgument.index++;
    if (PPTArgument.index > 3) {
        PPTArgument.index = 0
    }
    timer=window.setTimeout('plays()',3000);
}

//标签切换
function tabSwitch(event,tabList){
    var tabList=tabList.childNodes;
    //需要切换tab集合
    var tabs={
        plane:document.getElementById("plane"),
        webPage:document.getElementById("web-page"),
        mobileAPP:document.getElementById("mobile-APP"),
        illustration:document.getElementById("illustration")
    };
    //获取事件的目标对象
    var target=event.target;
    if(target.tagName==='A'){
        switch(target.id){
            case "a-plane":utils.removeClass(tabs.plane,"hidden");break;
            case "a-web-page":utils.addClass(tabs.plane,"hidden");utils.removeClass(tabs.webPage,"hidden");break;
            case "a-mobile-APP":utils.addClass(tabs.plane,"hidden");utils.addClass(tabs.webPage,"hidden");
                utils.removeClass(tabs.mobileAPP,"hidden");break;
            case "a-illustration":utils.addClass(tabs.plane,"hidden");utils.addClass(tabs.webPage,"hidden");
                utils.addClass(tabs.mobileAPP,"hidden");break;
            default :utils.removeClass(tabs.plane,"hidden");break;
        };
        for(var i= 1,len=tabList.length;i<len;i+=2){
            var index=tabList[i].childNodes[0];
            if(index.id!==target.id){
                utils.removeClass(index,'works-show-index-selected');
            }else{
                utils.addClass(index,'works-show-index-selected');
            }
        }
    }
}