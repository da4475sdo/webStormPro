/**
 * Created by Administrator on 2015/9/11.
 */
var img=new Image();
alert("1");
//img.src="image/cross.png";
//document.body.appendChild(img);