/**
 * Created by Administrator on 2015/9/17.
 */
(function(){
    var navBtn=document.getElementById("nav-btn");
    utils.eventUtil.addEvent(navBtn,"click",function (){
        var navList=document.getElementById("nav-btn-list");
        if(navList.className.indexOf("nav-btn-list-display")===-1){
            utils.addClass(navList,"nav-btn-list-display");
        }else{
            utils.removeClass(navList,"nav-btn-list-display");
        }
    },false);
})();