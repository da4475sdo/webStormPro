/**
 * Created by 周哥 on 2015/5/31.
 */
var DZ_Compass={
    properties:[//罗盘的显示列表
        {
            "index":1,
            "name":"推荐贴"
        },
        {
            "index":2,
            "name":"教务贴"
        },
        {
            "index":3,
            "name":"学工贴"
        },
        {
            "index":4,
            "name":"政策贴"
        },
        {
            "index":5,
            "name":"我的贴"
        },
        {
            "index":6,
            "name":"其他贴"
        }
    ],
    init:init,//罗盘的初始化函数
    miniRadius:0,//罗盘外圆的最小半径
    maxRadius:0,//罗盘外圆的最大半径
    radius:0,//罗盘外圆的半径
    returnSelectValue:null,//点击罗盘选项后返回的值
    compassOpen:false,
    selectedIndex:-1,
    clickSelectionIndex:function(){},//点击罗盘选项事件
    clickCompassOpen:function(){},//点击罗盘展开事件
    clickCompassClose:function(){}//点击罗盘收起事件
};

var DZ_Compass_InnerVar={
    timer:undefined,//定时器
    context:"",//画板
    radiusIncrease:20,//增加量
    indexTimer:undefined, //选项生成计时器
    selectionIndex:0,//选项下标
    isCompassOpen:DZ_Compass.compassOpen,//罗盘是否展开
    handlers:[],//选项的绑定事件变量
    selectedIndex:DZ_Compass.selectedIndex,//当前选中的选项下标
    clickAccess:true,//是否可以点击
    compassAngle:0,//罗盘展开的弧度
    centerOfCircleX:0,//圆心X坐标
    centerOfCircleY:0,//圆心Y坐标
    baseHeight:0,//外画布距离浏览器顶部的高度
    outerCanvas:undefined,//外画布对象
    outerCanvasHeight:0,//外画布的高度
    touchStartPageY:0,//触摸前的Y坐标
    touchMovePageY:0//触摸后的Y坐标
};

//初始化罗盘
function init(property){
    //初始化罗盘的起始选中项
    DZ_Compass_InnerVar.selectedIndex=DZ_Compass.selectedIndex - 1;
    DZ_Compass.properties=property;
    //生成绑定元素
    var container=document.createElement("div");
    container.id="DZ";
    container.className="DZ draggable";
    var handler=clickCompass;
    container.addEventListener("touchend",handler,false);
    document.body.appendChild(container);

    //生成中心圆元素
    var img=document.createElement("img");
    //img.src=localURl + "client/images/conMailbox/classification.png";
    img.src="classification.png";
    container.appendChild(img);
    clickCompass();
    //开启拖动
    container.addEventListener("touchstart",function(event){
        handlerEvent(event);
    },false);
    container.addEventListener("touchmove",function(event){
        handlerEvent(event);
    },false);
    container.addEventListener("touchend",function(event){
        handlerEvent(event);
    },false);
}

//生成罗盘
function compassBuild(){
    //生成中心圆元素
    var img=document.getElementById("DZ").getElementsByTagName("img")[0];

    //生成外围圆
    var imgHeight=img.clientHeight;
    var imgWidth=img.clientWidth;
    var canvasHeight=0;
    var canvasWidth=0;

    var parent=document.getElementById("DZ");
    var canvas=document.createElement("canvas");
    canvas.id="canvas";
    canvas.height=234;
    canvas.width=165;

    canvasHeight=canvas.height;
    canvasWidth=canvas.width;
    canvas.style.top=(parent.offsetTop+(imgHeight/2)-canvasHeight/2)+"px";
    //将图片插入到画板的前面
    document.body.insertBefore(canvas,parent);
    DZ_Compass_InnerVar.outerCanvas=canvas;
    //确定浏览器是否支持canvas标签
    if(canvas.getContext){
        DZ_Compass_InnerVar.context=canvas.getContext("2d");
        //开始路径
        DZ_Compass_InnerVar.context.beginPath();

        //绘制内圆
        var innerX=canvasWidth-imgWidth/2-9;
        var innerY=canvasHeight/2;
        DZ_Compass_InnerVar.baseHeight=parseInt(canvas.style.top.toString().substr(0,canvas.style.top.toString().length-2));
        DZ_Compass_InnerVar.centerOfCircleX=canvasWidth-innerX;
        DZ_Compass_InnerVar.centerOfCircleY=innerY;
        DZ_Compass.miniRadius=imgWidth/2-2;
        DZ_Compass.maxRadius=canvasHeight/2;
        DZ_Compass.radius=DZ_Compass.miniRadius;
        DZ_Compass_InnerVar.context.arc(innerX,innerY,DZ_Compass.miniRadius,0,2*Math.PI,false);
        DZ_Compass_InnerVar.context.strokeStyle="#88be36";
        DZ_Compass_InnerVar.context.stroke();

        //绘制外圆
        DZ_Compass_InnerVar.timer=window.setInterval("outerBuild("+innerX+","+innerY+")",70);

        //获取外圆展开的最大可见弧度
        getMaxRadian(innerX,innerX+DZ_Compass.maxRadius);
    }
}

//生成外圆
function outerBuild(innerX,innerY){
    DZ_Compass_InnerVar.context.clearRect(0,0,DZ_Compass.maxRadius*2,DZ_Compass.maxRadius*2);
    DZ_Compass_InnerVar.context.arc(innerX,innerY,DZ_Compass.radius,0,2*Math.PI,false);
    DZ_Compass_InnerVar.context.fillStyle="rgba(169,213,102,0.7)";
    DZ_Compass_InnerVar.context.fill();
    DZ_Compass.radius+=DZ_Compass_InnerVar.radiusIncrease;
    if(DZ_Compass.radius>=DZ_Compass.maxRadius) {
        window.clearInterval(DZ_Compass_InnerVar.timer);
        DZ_Compass_InnerVar.indexTimer=window.setInterval("indexBuilder("+innerX+","+innerY+")",70);
    }
}

//生成选项
function indexBuilder(innerX,innerY){
    //选项所围成圆的半径
    var indexesRadius=DZ_Compass.maxRadius*0.7;
    //选项圆的半径
    var indexRadius=DZ_Compass.miniRadius*0.7;

    var canvas=document.createElement("canvas");
    canvas.width=indexRadius*2+2;
    canvas.height=indexRadius*2+2;
    canvas.style.position="absolute";

    var mainCanvas=DZ_Compass_InnerVar.outerCanvas;
    var mainWidth=mainCanvas.width;
    var mainHeight=mainCanvas.height;
    if(DZ_Compass.properties.length>3){
        var index=2-DZ_Compass_InnerVar.selectionIndex;
        var extraAdd=DZ_Compass_InnerVar.selectionIndex>=0?0.5:-0.5;
        var radian=(index+extraAdd)*(DZ_Compass_InnerVar.compassAngle/6);
        var offsetX=indexesRadius*Math.cos(radian);
        var offsetY=indexesRadius*Math.sin(radian);
        canvas.style.right=((DZ_Compass_InnerVar.centerOfCircleX
                + offsetX-indexRadius-1)>>0)+"px";
        canvas.style.top=((DZ_Compass_InnerVar.centerOfCircleY
            - offsetY+DZ_Compass_InnerVar.baseHeight-20)>>0)+"px";
    }else{
        var offsetX=indexesRadius*Math.sin(DZ_Compass_InnerVar.selectionIndex*Math.PI/2);
        var offsetY=indexesRadius*Math.cos(DZ_Compass_InnerVar.selectionIndex*Math.PI/2);
        canvas.style.right=((DZ_Compass_InnerVar.centerOfCircleX + offsetX-indexRadius-1)>>0)+"px";
        canvas.style.top=((DZ_Compass_InnerVar.centerOfCircleY - offsetY+DZ_Compass_InnerVar.baseHeight-20)>>0)+"px";
    }
    canvas.id=(DZ_Compass_InnerVar.selectionIndex+1)+"";
    canvas.style.zIndex=100;
    //绑定触摸结束事件
    var clickHandler=function (event){
        EventUtil.preventDefault(event);
        clickSelectionIndex(canvas);
        //EventUtil.stopPropagation(event);
    };
    var touchstartHandler=function (event){
        touchSelectionIndex(canvas);
        EventUtil.stopPropagation(event);
    };
    //将监听器存入监听器数组
    DZ_Compass_InnerVar.handlers.push(clickHandler);
    DZ_Compass_InnerVar.handlers.push(touchstartHandler);
    //canvas.addEventListener("touchstart",touchstartHandler,false);
    canvas.addEventListener("touchstart",clickHandler,false);

    document.body.appendChild(canvas);
    if(DZ_Compass_InnerVar.selectionIndex!==DZ_Compass_InnerVar.selectedIndex||DZ_Compass_InnerVar.selectedIndex===-1){
        drawSelection(canvas.getContext("2d"),DZ_Compass_InnerVar.selectionIndex);
    }else{
        drawSelectedSelection(canvas.getContext("2d"),DZ_Compass_InnerVar.selectionIndex);
    }

    //增加下标
    if(DZ_Compass_InnerVar.selectionIndex<DZ_Compass.properties.length-1) {
        DZ_Compass_InnerVar.selectionIndex++;
    }else{
        window.clearInterval(DZ_Compass_InnerVar.indexTimer);
        DZ_Compass_InnerVar.clickAccess=true;
    }
}

//点击罗盘选项后
function clickSelectionIndex(canvas){
    DZ_Compass_InnerVar.selectedIndex=parseInt(canvas.id)-1;
    drawSelection(canvas.getContext("2d"),parseInt(canvas.id)-1);
    DZ_Compass.returnSelectValue=canvas.id;
    DZ_Compass.clickSelectionIndex();
}

//接触到罗盘选项时
function touchSelectionIndex(canvas){
    drawSelectedSelection(canvas.getContext("2d"),parseInt(canvas.id)-1);
}


//收起罗盘
function stopCompass(){
    var canvasList=document.getElementsByTagName("canvas");
    var i=0;
    while(canvasList.length>0){
        canvasList[0].removeEventListener("touchstart",DZ_Compass_InnerVar.handlers[i]);
        canvasList[0].removeEventListener("touchend",DZ_Compass_InnerVar.handlers[i+1]);
        document.body.removeChild(canvasList[0]);
        i+=2;
    }
    DZ_Compass_InnerVar.isCompassOpen=true;
    DZ_Compass_InnerVar.selectionIndex=0;
    DZ_Compass_InnerVar.clickAccess=true;
}

//点击罗盘
function clickCompass(){
    //罗盘展开完成后才可点击
    if(DZ_Compass_InnerVar.clickAccess) {
        //在罗盘滑动的时候不展开罗盘
        if (DZ_Compass_InnerVar.touchStartPageY === DZ_Compass_InnerVar.touchMovePageY) {
            DZ_Compass_InnerVar.clickAccess = false;
            if (!DZ_Compass_InnerVar.isCompassOpen) {
                stopCompass();
                DZ_Compass.clickCompassClose();
                DZ_Compass_InnerVar.isCompassOpen = true;
            } else {
                compassBuild();
                DZ_Compass.clickCompassOpen();
                DZ_Compass_InnerVar.isCompassOpen = false;
            }
        } else {
            stopCompass();
        }
    }
}

//绘画选项
function drawSelection(context,index){
    var radius=DZ_Compass.miniRadius*0.7;
    context.beginPath();
    context.clearRect(0,0,radius*2,radius*2);
    context.arc(radius+1,radius+1,radius,0,2*Math.PI,false);
    context.strokeStyle="#f5f5f5";
    context.stroke();

    //填充文字
    context.font="bold 11px Arial";
    context.textAlign="center";
    context.textBaseline="middle";
    context.fillStyle="#ffffff";
    context.fillText(DZ_Compass.properties[parseInt(index)].name,radius*1.1,radius*1.1);
}

//绘画选中后的选项
function drawSelectedSelection(context,index){
    var radius=DZ_Compass.miniRadius*0.7;
    context.beginPath();
    context.clearRect(0,0,radius*2,radius*2);
    context.arc(radius+1,radius+1,radius,0,2*Math.PI,false);
    context.strokeStyle="#fc8b35";
    context.stroke();
    //填充文字
    context.font="bold 11px Arial";
    context.textAlign="center";
    context.textBaseline="middle";
    context.fillStyle="#fc8b35";
    context.fillText(DZ_Compass.properties[parseInt(index)].name,radius*1.1,radius*1.1);
}

//获得外圆展开的最大可见弧度
function getMaxRadian(shortLine,longLine){
    DZ_Compass_InnerVar.compassAngle=6.28-(2*Math.acos(shortLine/longLine));
}


//拖放事件
function handlerEvent(event){
    //获取事件和目标
    event=EventUtil.getEvent(event);
    var childTarget=EventUtil.getTarget(event);
    var target=childTarget.parentNode;
    //确定事件类型
    switch(event.type){
        case "touchstart":
            EventUtil.preventDefault(event);
            DZ_Compass_InnerVar.touchStartPageY=event.touches[0].pageY;
            DZ_Compass_InnerVar.touchMovePageY=event.touches[0].pageY;
        case "touchmove":
            EventUtil.preventDefault(event);
            //罗盘未完全展开时，不允许移动
            if(DZ_Compass_InnerVar.clickAccess){
                if(target!==null){
                    var pageY=event.targetTouches[0].pageY;
                    if(Math.abs(pageY-DZ_Compass_InnerVar.touchMovePageY)>10){
                        DZ_Compass_InnerVar.outerCanvasHeight = childTarget.clientHeight / 2;
                        var top = pageY - DZ_Compass_InnerVar.outerCanvasHeight;
                        //拖动时关闭罗盘
                        stopCompass();
                        if (top >= 60 && top <= 350) {
                            //指定位置
                            target.style.top = top + "px";
                        }
                        DZ_Compass_InnerVar.touchMovePageY=pageY;
                    }
                }
            }
            break;
        case "touchend":
            EventUtil.preventDefault(event);
            break;
    }
}

//事件工具
var EventUtil={
    addHandler:function(element,type,handler){
      if(element.addEventListener){
          element.addEventListener(type,handler,false);
      }else if(element.attachEvent){
          element.attachEvent("on"+type,handler);
      }else{
          element["on"+type]=handler;
      }
    },
    removeHandler:function (element,type,handler){
        if(element.removeEventListener){
            element.removeEventListener(type,handler,false);
        }else if(element.detachEvent){
            element.detachEvent("on"+type,handler);
        }else{
            element["on"+type]=null;
        }
    },
    getEvent:function(event){
        return event?event:window.event;
    },
    getTarget:function(event){
        return event.target||event.srcElement;
    },
    preventDefault:function(event){
        if(event.preventDefault){
            event.preventDefault();
        }else{
            event.returnValue=false;
        }
    },
    stopPropagation:function(event){
        if(event.stopPropagation){
            event.stopPropagation();
        }else{
            event.cancelBubble=true;
        }
    }
};

