/**
 * Created by Administrator on 2015/9/17.
 */

(function () {
    window.addEventListener("deviceorientation", handleOrientation, true);

    function handleOrientation(event) {
        var absolute = event.absolute;
        var alpha    = event.alpha;
        var beta     = event.beta;
        var gamma    = event.gamma;
        var compass=document.getElementById("compass");
        compass.style.transform='rotate('+ (180+alpha) +'deg)';
    }
})();

